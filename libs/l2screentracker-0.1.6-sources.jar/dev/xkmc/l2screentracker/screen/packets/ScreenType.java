package dev.xkmc.l2screentracker.screen.packets;

import java.util.function.Supplier;

public enum ScreenType {
	NONE(() -> ScreenTypeClient::none),
	PLAYER(() -> ScreenTypeClient::player);

	private final Supplier<Runnable> callback;

	ScreenType(Supplier<Runnable> callback) {
		this.callback = callback;
	}

	public void perform() {
		callback.get().run();
	}

}
