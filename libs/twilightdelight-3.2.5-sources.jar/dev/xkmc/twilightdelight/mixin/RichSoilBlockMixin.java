package dev.xkmc.twilightdelight.mixin;

import dev.xkmc.twilightdelight.compat.TGCompat;
import dev.xkmc.twilightdelight.content.block.FiddleheadClumpBlock;
import dev.xkmc.twilightdelight.init.registrate.TDBlocks;
import dev.xkmc.twilightdelight.util.RichSoilUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import twilightforest.init.TFBlocks;
import vectorwing.farmersdelight.common.block.RichSoilBlock;

@Mixin(RichSoilBlock.class)
public class RichSoilBlockMixin {

	@Inject(at = @At("HEAD"), method = "randomTick", cancellable = true)
	public void twilightdelight$randomTick$growMushgloomAndRoot(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand, CallbackInfo ci) {
		if (!level.isClientSide) {
			RichSoilUtil.convert(pos, level);
			BlockPos abovePos = pos.above();
			BlockState aboveState = level.getBlockState(abovePos);
			Block aboveBlock = aboveState.getBlock();
		if (aboveBlock == TFBlocks.MUSHGLOOM.get()) {
			// Twilit Gourmet grows its own colony from mushgloom (via bonemeal);
			// defer to it when its colony exists so only one colony type is obtainable
			if (TGCompat.isItemPresent(TGCompat.loc("mushgloom_colony"))) return;
			level.setBlockAndUpdate(pos.above(), TDBlocks.MUSHGLOOM_COLONY.get().defaultBlockState());
			ci.cancel();
		}
		if (aboveBlock == TFBlocks.FIDDLEHEAD.get()) {
			level.setBlockAndUpdate(pos.above(), TDBlocks.FIDDLEHEAD_CLUMP.get().defaultBlockState());
			ci.cancel();
		}
		}
	}

}
