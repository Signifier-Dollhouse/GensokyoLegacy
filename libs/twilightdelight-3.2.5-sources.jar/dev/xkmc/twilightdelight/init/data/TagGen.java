package dev.xkmc.twilightdelight.init.data;

import com.teamabnormals.neapolitan.core.Neapolitan;
import com.tterrag.registrate.providers.RegistrateItemTagsProvider;
import com.tterrag.registrate.providers.RegistrateTagsProvider;
import dev.xkmc.twilightdelight.compat.TGCompat;
import dev.xkmc.twilightdelight.init.TwilightDelight;
import dev.xkmc.twilightdelight.init.registrate.TDBlocks;
import dev.xkmc.twilightdelight.init.registrate.delight.DelightFood;
import dev.xkmc.twilightdelight.init.registrate.neapolitan.NeapolitanCakes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.common.Tags;
import twilightforest.init.TFBlocks;
import twilightforest.init.TFItems;
import vectorwing.farmersdelight.common.tag.ModTags;

public class TagGen {

	public static final TagKey<Item> INSECT = ItemTags.create(ResourceLocation.fromNamespaceAndPath("c", "foods/insect"));
	public static final TagKey<Item> HYDRA_MEAT = ItemTags.create(TwilightDelight.loc("hydra_meat"));
	public static final TagKey<Item> MEEF_COOKED = ItemTags.create(TwilightDelight.loc("meef_cooked"));
	public static final TagKey<Item> MEEF_RAW = ItemTags.create(TwilightDelight.loc("meef_raw"));
	public static final TagKey<Item> VENSION_COOKED = ItemTags.create(TwilightDelight.loc("vension_cooked"));
	public static final TagKey<Item> VENSION_RAW = ItemTags.create(TwilightDelight.loc("vension_raw"));
	public static final TagKey<Item> NAGA_COOKED = ItemTags.create(TwilightDelight.loc("naga_cooked"));
	public static final TagKey<Item> NAGA_RAW = ItemTags.create(TwilightDelight.loc("naga_raw"));

	public static void genItemTag(RegistrateItemTagsProvider pvd) {
		pvd.addTag(INSECT)
				.add(TFBlocks.FIREFLY.get().asItem(),
						TFBlocks.CICADA.get().asItem(),
						TFBlocks.MOONWORM.get().asItem());
		pvd.addTag(Tags.Items.FOODS).addTag(INSECT);
		pvd.addTag(HYDRA_MEAT).add(TFItems.HYDRA_CHOP.get(), DelightFood.HYDRA_PIECE.item.get());
		pvd.addTag(MEEF_COOKED).add(TFItems.COOKED_MEEF.get(), DelightFood.COOKED_MEEF_SLICE.item.get())
				.addOptional(TGCompat.loc("meef_patty"));
		pvd.addTag(MEEF_RAW).add(TFItems.RAW_MEEF.get(), DelightFood.RAW_MEEF_SLICE.item.get())
				.addOptional(TGCompat.loc("minced_meef"));
		pvd.addTag(VENSION_COOKED).add(TFItems.COOKED_VENISON.get(), DelightFood.COOKED_VENISON_RIB.item.get())
				.addOptional(TGCompat.loc("venison_patty"));
		pvd.addTag(VENSION_RAW).add(TFItems.RAW_VENISON.get(), DelightFood.RAW_VENISON_RIB.item.get())
				.addOptional(TGCompat.loc("ground_venison"));
		pvd.addTag(NAGA_COOKED).add(DelightFood.COOKED_NAGA_MEAT.item.get(), DelightFood.COOKED_NAGA_PIECE.item.get());
		pvd.addTag(NAGA_RAW).add(DelightFood.RAW_NAGA_MEAT.item.get(), DelightFood.RAW_NAGA_PIECE.item.get());
	}

	public static void genBlockTag(RegistrateTagsProvider.IntrinsicImpl<Block> pvd) {
		pvd.addTag(TagRef.HEAT_SOURCES).add(TFBlocks.FIERY_BLOCK.get());
		pvd.addTag(ModTags.Blocks.MUSHROOM_COLONY_GROWABLE_ON).add(TDBlocks.TWILIGHT_RICH_SOIL.get());
		pvd.addTag(BlockTags.DIRT).add(TDBlocks.TWILIGHT_RICH_SOIL.get());
		pvd.addTag(BlockTags.MUSHROOM_GROW_BLOCK).add(TDBlocks.TWILIGHT_RICH_SOIL.get());
		pvd.addTag(BlockTags.BAMBOO_PLANTABLE_ON).add(TDBlocks.TWILIGHT_RICH_SOIL.get());
		var candle = pvd.addTag(BlockTags.CANDLE_CAKES);
		if (ModList.get().isLoaded(Neapolitan.MOD_ID)) {
			for (var e : NeapolitanCakes.values()) {
				candle.addOptional(e.candle.getId());
				for (var c : e.colored_candles)
					candle.addOptional(c.getId());
			}
		}
	}

}
