package dev.xkmc.twilightdelight.init.data;

import com.tterrag.registrate.providers.RegistrateRecipeProvider;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.ItemEntry;
import com.teamabnormals.neapolitan.core.Neapolitan;
import com.teamabnormals.neapolitan.core.registry.NeapolitanItems;
import dev.xkmc.l2core.serial.recipe.ConditionalRecipeWrapper;
import dev.xkmc.l2core.serial.recipe.DataRecipeWrapper;
import dev.xkmc.twilightdelight.compat.TGCompat;
import dev.xkmc.l2core.serial.recipe.CustomShapedBuilder;
import dev.xkmc.twilightdelight.content.recipe.ScepterDuplicateRecipe;
import dev.xkmc.twilightdelight.content.recipe.SimpleFrozenRecipeBuilder;
import dev.xkmc.twilightdelight.init.TwilightDelight;
import dev.xkmc.twilightdelight.init.registrate.TDBlocks;
import dev.xkmc.twilightdelight.init.registrate.TDItems;
import dev.xkmc.twilightdelight.init.registrate.delight.DelightFood;
import dev.xkmc.twilightdelight.init.registrate.delight.DelightPie;
import dev.xkmc.twilightdelight.init.registrate.delight.DelightCake;
import dev.xkmc.twilightdelight.init.registrate.neapolitan.NeapolitanCakes;
import dev.xkmc.twilightdelight.init.registrate.neapolitan.NeapolitanFood;
import net.minecraft.advancements.Criterion;
import net.minecraft.advancements.critereon.InventoryChangeTrigger;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.data.recipes.ShapedRecipeBuilder;
import net.minecraft.data.recipes.ShapelessRecipeBuilder;
import net.minecraft.data.recipes.SimpleCookingRecipeBuilder;
import net.minecraft.data.recipes.SmithingTransformRecipeBuilder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.common.ItemAbilities;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.registries.DeferredBlock;
import twilightforest.TwilightForestMod;
import twilightforest.data.tags.ItemTagGenerator;
import twilightforest.init.TFBlocks;
import twilightforest.init.TFItems;
import vectorwing.farmersdelight.client.recipebook.CookingPotRecipeBookTab;
import vectorwing.farmersdelight.common.crafting.ingredient.ItemAbilityIngredient;
import vectorwing.farmersdelight.common.registry.ModBlocks;
import vectorwing.farmersdelight.common.registry.ModItems;
import vectorwing.farmersdelight.data.builder.CookingPotRecipeBuilder;
import vectorwing.farmersdelight.data.builder.CuttingBoardRecipeBuilder;

import java.util.function.BiFunction;
import java.util.function.Supplier;

public class RecipeGen {

	private static String path = "";

	public static void genRecipes(RegistrateRecipeProvider pvd) {

		// tool crafting
		{

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.MISC, TDItems.FIERY_KNIFE.get(), 1)::unlockedBy, TFItems.FIERY_INGOT.get())
				.pattern("A").pattern("B")
				.define('A', TFItems.FIERY_INGOT.get())
				.define('B', Items.BLAZE_ROD)
				.save(TGCompat.noTG(pvd, TGCompat.loc("fiery_knife")));

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.MISC, TDItems.FIERY_KNIFE.get(), 1)::unlockedBy, TFItems.FIERY_INGOT.get())
				.requires(ModItems.IRON_KNIFE.get())
				.requires(ItemTagGenerator.FIERY_VIAL)
				.requires(Items.BLAZE_ROD)
				.save(TGCompat.noTG(pvd, TGCompat.loc("fiery_knife")), getID(TDItems.FIERY_KNIFE.getId(), "alt"));

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.MISC, TDItems.IRONWOOD_KNIFE.get(), 1)::unlockedBy, TFItems.IRONWOOD_INGOT.get())
				.pattern("A").pattern("B")
				.define('A', TFItems.IRONWOOD_INGOT.get())
				.define('B', Tags.Items.RODS_WOODEN)
				.save(ConditionalRecipeWrapper.of(new DataRecipeWrapper(pvd, TDItems.IRONWOOD_KNIFE.get().getDefault(pvd.getProvider())), TGCompat.absentOf(TGCompat.loc("ironwood_knife"))));

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.MISC, TDItems.STEELEAF_KNIFE.get(), 1)::unlockedBy, TFItems.STEELEAF_INGOT.get())
				.pattern("A").pattern("B")
				.define('A', TFItems.STEELEAF_INGOT.get())
				.define('B', Tags.Items.RODS_WOODEN)
				.save(ConditionalRecipeWrapper.of(new DataRecipeWrapper(pvd, TDItems.STEELEAF_KNIFE.get().getDefault(pvd.getProvider())), TGCompat.absentOf(TGCompat.loc("steeleaf_knife"))));

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.MISC, TDItems.KNIGHTMETAL_KNIFE.get(), 1)::unlockedBy, TFItems.KNIGHTMETAL_INGOT.get())
				.pattern("A").pattern("B")
				.define('A', TFItems.KNIGHTMETAL_INGOT.get())
				.define('B', Tags.Items.RODS_WOODEN)
				.save(TGCompat.noTG(pvd, TGCompat.loc("knightmetal_knife")));

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.MISC, TDItems.WROUGHT_IRON_SWORD.get(), 1)::unlockedBy, Items.IRON_INGOT)
				.pattern("A").pattern("A").pattern("B")
				.define('A', TFItems.WROUGHT_IRON_BAR)
				.define('B', Tags.Items.RODS_WOODEN)
				.save(pvd);

			unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.MISC, TDBlocks.MAZE_STOVE.get(), 1)::unlockedBy, TFItems.KNIGHTMETAL_INGOT.get())
					.pattern("KKK").pattern("MTM").pattern("MCM")
					.define('K', TFItems.KNIGHTMETAL_INGOT.get())
					.define('M', TFBlocks.MAZESTONE_BRICK.get())
					.define('T', TFItems.TORCHBERRIES.get())
					.define('C', Items.CAMPFIRE)
					.save(pvd);

			unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.MISC, TDBlocks.FIERY_POT.get(), 1)::unlockedBy, TFItems.FIERY_INGOT.get())
					.pattern("BSB").pattern("FWF").pattern("FFF")
					.define('F', TFItems.FIERY_INGOT.get())
					.define('B', TFBlocks.MAZESTONE_BRICK.get())
					.define('S', TFItems.IRONWOOD_SHOVEL.get())
					.define('W', Items.WATER_BUCKET)
					.save(pvd);

			unlock(pvd, SmithingTransformRecipeBuilder.smithing(
					Ingredient.of(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE),
					Ingredient.of(TFItems.FIERY_SWORD.get()),
					Ingredient.of(DelightFood.EXPERIMENT_110.item.get()),
					RecipeCategory.MISC,
					TDItems.TEARDROP_SWORD.get())::unlocks, DelightFood.EXPERIMENT_110.item.get())
					.save(pvd, TDItems.TEARDROP_SWORD.getId());

			for (var e : TDBlocks.WoodTypes.values()) {
				String id = e.id();
				var cab = TDBlocks.CABINETS[e.ordinal()];
				var slab = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath(TwilightForestMod.ID, id + "_slab"));
				var trapdoor = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath(TwilightForestMod.ID, id + "_trapdoor"));
			unlock(pvd, ShapedRecipeBuilder.shaped(RecipeCategory.DECORATIONS, cab.get(), 1)::unlockedBy, slab)
					.pattern("---").pattern("D D").pattern("---")
					.define('-', slab).define('D', trapdoor)
					.save(TGCompat.noTG(pvd, TGCompat.loc(cab.getId().getPath())));
			}
		}

		//misc
		{
			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.MISC, TFItems.RAW_IRONWOOD.get(), 1)::unlockedBy,
					TFItems.LIVEROOT.get()).requires(TFItems.LIVEROOT.get())
					.requires(Items.IRON_INGOT).requires(Items.GOLD_NUGGET)
					.save(pvd, getID(TFItems.RAW_IRONWOOD.getId()));

			pvd.storage(TFItems.TORCHBERRIES::get, RecipeCategory.MISC, TDBlocks.TORCHBERRIES_CRATE);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.MISC, TDBlocks.TWILIGHT_RICH_SOIL.get(), 1)::unlockedBy,
					TFItems.LIVEROOT.get())
					.requires(ModBlocks.RICH_SOIL.get())
					.requires(TFItems.LIVEROOT.get())
					.save(pvd);

		}

		// smelting
		{

		tripleCook(pvd, DataIngredient.items(DelightFood.RAW_TOMAHAWK_SMEAK.item.get()), DelightFood.COOKED_TOMAHAWK_SMEAK.item, 1);
		tripleCook(pvd, DataIngredient.items(DelightFood.RAW_INSECT.item.get()), DelightFood.COOKED_INSECT.item, 1);
		tripleCook(pvd, DataIngredient.items(DelightFood.RAW_NAGA_MEAT.item.get()), DelightFood.COOKED_NAGA_MEAT.item, 1);
		tripleCook(pvd, DataIngredient.items(DelightFood.RAW_NAGA_PIECE.item.get()), DelightFood.COOKED_NAGA_PIECE.item, 1);
		// duplicated by Twilit Gourmet (ground venison / minced meef chain): disabled when it is present
		tripleCookCond(TGCompat.noTG(pvd, TGCompat.loc("minced_meef")),
				DelightFood.RAW_MEEF_SLICE.item.get(), DelightFood.COOKED_MEEF_SLICE.item, 1);
		tripleCookCond(TGCompat.noTG(pvd, TGCompat.loc("ground_venison")),
				DelightFood.RAW_VENISON_RIB.item.get(), DelightFood.COOKED_VENISON_RIB.item, 1);
		}

		// food crafting
		{

		delightPie(pvd, DelightPie.AURORA_PIE, TFBlocks.AURORA_BLOCK.get().asItem());
		delightPie(pvd, DelightPie.TORCHBERRY_PIE, TFItems.TORCHBERRIES.get());

		delightCake(pvd, DelightCake.TWILIGHT);

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.NAGA_SKEWERS.item.get(), 2)::unlockedBy, DelightFood.COOKED_NAGA_PIECE.item.get())
				.requires(TagGen.NAGA_COOKED)
				.requires(TagGen.NAGA_COOKED)
				.requires(Items.CARROT)
				.requires(Items.BAKED_POTATO)
				.requires(Tags.Items.RODS_WOODEN)
				.requires(Tags.Items.RODS_WOODEN).save(pvd);

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, TDBlocks.SAUCY_GRILLED_NAGA.get(), 1)::unlockedBy, DelightFood.COOKED_NAGA_MEAT.item.get())
				.pattern("MMM").pattern("CST").pattern(" B ")
				.define('M', TagGen.NAGA_COOKED)
				.define('C', Items.CARROT)
				.define('S', DelightFood.MUSHGLOOM_SAUCE.item.get())
				.define('T', TFItems.TORCHBERRIES.get())
				.define('B', Items.BOWL)
				.save(pvd);

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.MISC, TDItems.WITCHCRAFT_BONE_MEAL.get(), 3)::unlockedBy, TDItems.WITCHCRAFT_BONE.get())
				.requires(TDItems.WITCHCRAFT_BONE.get()).save(pvd);

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.MAGIC_CAKE_SCROLL.item.get(), 2)::unlockedBy, TDItems.WITCHCRAFT_BONE_MEAL.get())
				.requires(TDItems.WITCHCRAFT_BONE_MEAL.get())
				.requires(TDItems.WITCHCRAFT_BONE_MEAL.get())
				.requires(Items.WHEAT)
				.requires(Tags.Items.EGGS)
				.requires(TagRef.FOODS_MILK)
				.requires(Items.SUGAR).save(pvd);

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.BERRY_STICK.item.get(), 1)::unlockedBy, TFItems.TORCHBERRIES.get())
				.requires(Items.SWEET_BERRIES).requires(Items.GLOW_BERRIES).requires(TFItems.TORCHBERRIES.get())
				.requires(Tags.Items.RODS_WOODEN).save(pvd);

			unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, DelightFood.TORCHBERRY_COOKIE.item.get(), 8)::unlockedBy, TFItems.TORCHBERRIES.get())
					.pattern("BAB")
					.define('A', TFItems.TORCHBERRIES.get())
					.define('B', Items.WHEAT)
					.save(pvd);

			unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, TFItems.MAZE_WAFER.get(), 12)::unlockedBy, TFItems.LIVEROOT.get())
					.pattern("AAA").pattern("BCB").pattern("AAA")
					.define('A', Items.WHEAT)
					.define('B', TagRef.FOODS_MILK)
					.define('C', TFItems.LIVEROOT.get())
					.save(pvd, getID(TFItems.MAZE_WAFER.getId()));

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.GLACIER_ICE_TEA.item.get(), 1)::unlockedBy, TFItems.ICE_BOMB.get())
					.requires(Items.GLASS_BOTTLE).requires(TFItems.ICE_BOMB.get())
					.requires(Items.ICE).requires(TFItems.ARCTIC_FUR.get())
					.requires(Items.SUGAR).save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.TWILIGHT_SPRING.item.get(), 1)::unlockedBy, TFItems.RAW_IRONWOOD.get())
					.requires(Items.GLASS_BOTTLE).requires(TFItems.RAW_IRONWOOD.get()).requires(Items.ICE).save(pvd);

			unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, TDBlocks.MEEF_WELLINGTON.get(), 1)::unlockedBy, DelightFood.MUSHGLOOM_SAUCE.item.get())
					.pattern("BAB").pattern("DCD").pattern("FEF")
					.define('A', ModItems.PIE_CRUST.get())
					.define('B', Tags.Items.EGGS)
					.define('C', DelightFood.MUSHGLOOM_SAUCE.item.get())
					.define('D', TagGen.MEEF_COOKED)
					.define('E', Items.BOWL)
					.define('F', ModItems.BACON.get())
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.MEEF_WRAP.item.get(), 1)::unlockedBy, TFItems.RAW_MEEF.get())
					.requires(Tags.Items.FOODS_BREAD).requires(TagGen.MEEF_COOKED)
					.requires(TagRef.FOODS_LEAFY_GREEN)
					.requires(TagRef.FOODS_ONION)
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.TORCHBERRY_VENISON_SANDWICH.item.get(), 1)::unlockedBy, TFItems.RAW_VENISON.get())
					.requires(Tags.Items.FOODS_BREAD).requires(TagGen.VENSION_COOKED)
					.requires(TagRef.FOODS_LEAFY_GREEN)
					.requires(TFItems.TORCHBERRIES.get())
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.CHOCOLATE_113.item.get(), 1)::unlockedBy, DelightFood.EXPERIMENT_113.item.get())
					.requires(DelightFood.EXPERIMENT_113.item.get())
					.requires(TagRef.FOODS_MILK)
					.requires(Items.SUGAR)
					.requires(Items.COCOA_BEANS)
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.MILKY_113.item.get(), 1)::unlockedBy, DelightFood.EXPERIMENT_113.item.get())
					.requires(DelightFood.EXPERIMENT_113.item.get())
					.requires(TagRef.FOODS_MILK)
					.requires(Items.SUGAR)
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.HONEY_113.item.get(), 1)::unlockedBy, DelightFood.EXPERIMENT_113.item.get())
					.requires(DelightFood.EXPERIMENT_113.item.get())
					.requires(Items.HONEY_BOTTLE)
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.GLOW_113.item.get(), 1)::unlockedBy, DelightFood.EXPERIMENT_113.item.get())
					.requires(DelightFood.EXPERIMENT_113.item.get())
					.requires(DelightFood.GLOWSTEW.item.get())
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.GHAST_BURGER.item.get(), 1)::unlockedBy, TFItems.EXPERIMENT_115.get())
					.requires(Tags.Items.FOODS_BREAD)
					.requires(TFItems.EXPERIMENT_115.get())
					.requires(Tags.Items.CROPS_BEETROOT)
					.requires(TagRef.FOODS_TOMATO)
					.requires(TagRef.FOODS_ONION)
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.HYDRA_BURGER.item.get(), 1)::unlockedBy, TFItems.HYDRA_CHOP.get())
					.requires(Tags.Items.FOODS_BREAD)
					.requires(TagGen.HYDRA_MEAT)
					.requires(TagRef.FOODS_LEAFY_GREEN)
					.requires(TagRef.FOODS_TOMATO)
					.requires(TagRef.FOODS_ONION)
					.save(pvd);

			unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, DelightFood.CHOCOLATE_WAFER.item.get(), 1)::unlockedBy, TFItems.MAZE_WAFER.get())
					.pattern("A").pattern("B").pattern("A")
					.define('A', TFItems.MAZE_WAFER.get())
					.define('B', Items.COCOA_BEANS)
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.BORER_TEAR_SOUP.item.get(), 1)::unlockedBy, TFItems.BORER_ESSENCE.get())
					.requires(Items.BOWL)
					.requires(Items.BEETROOT)
					.requires(Items.BEETROOT)
					.requires(Items.BEETROOT)
					.requires(Items.BEETROOT)
					.requires(TFItems.BORER_ESSENCE.get())
					.save(pvd);

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, DelightFood.GHAST_BRAIN_SALAD.item.get(), 1)::unlockedBy, DelightFood.EXPERIMENT_110.item.get())
					.requires(Items.BOWL)
					.requires(TagRef.FOODS_LEAFY_GREEN)
					.requires(TagRef.FOODS_ONION)
					.requires(TagRef.FOODS_TOMATO)
					.requires(DelightFood.EXPERIMENT_110.item.get())
					.requires(TFItems.BORER_ESSENCE.get())
					.requires(TFItems.TRANSFORMATION_POWDER.get())
					.save(pvd);

		}

		//food cooking
		{
			path = "cooking/";
			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(TDBlocks.FIERY_SNAKES.get().asItem(),
							1, 800, 0.5f, Items.BOWL)::unlockedBy,
					TFItems.FIERY_BLOOD.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(TagGen.HYDRA_MEAT)
					.addIngredient(ItemTagGenerator.FIERY_VIAL)
					.addIngredient(TFItems.NAGA_SCALE.get())
					.addIngredient(ModItems.TOMATO_SAUCE.get())
					.addIngredient(TFItems.TORCHBERRIES.get())
					.save(pvd, getID(TDBlocks.FIERY_SNAKES.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.FRIED_INSECT.item.get().asItem(),
						1, 200, 0.35f, Items.BOWL)::unlockedBy,
				DelightFood.RAW_INSECT.item.get())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(DelightFood.RAW_INSECT.item.get())
				.addIngredient(TagRef.FOODS_ONION)
				.addIngredient(Items.CARROT)
				.save(pvd, getID(DelightFood.FRIED_INSECT.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.GLOWSTEW.item.get(),
							1, 200, 0.35f, Items.BOWL)::unlockedBy,
					TFBlocks.MUSHGLOOM.get().asItem())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(Items.GLOWSTONE_DUST)
					.addIngredient(TFBlocks.MUSHGLOOM.get().asItem())
					.addIngredient(TFItems.TORCHBERRIES.get())
					.save(pvd, getID(DelightFood.GLOWSTEW.item.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.MUSHGLOOM_SAUCE.item.get(),
						1, 200, 0.35f, Items.BOWL)::unlockedBy,
				TFBlocks.MUSHGLOOM.get().asItem())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(Items.BROWN_MUSHROOM)
				.addIngredient(TFBlocks.MUSHGLOOM.get().asItem())
				.addIngredient(TagRef.FOODS_ONION)
				.save(pvd, getID(DelightFood.MUSHGLOOM_SAUCE.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.GLOW_VENISON_RIB_WITH_PASTA.item.get(),
							1, 200, 0.35f, Items.BOWL)::unlockedBy,
					DelightFood.GLOWSTEW.item.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(DelightFood.GLOWSTEW.item.get())
					.addIngredient(TagGen.VENSION_RAW)
					.addIngredient(ModItems.RAW_PASTA.get())
					.addIngredient(TFItems.LIVEROOT.get())
					.addIngredient(Items.BEETROOT)
					.save(pvd, getID(DelightFood.GLOW_VENISON_RIB_WITH_PASTA.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.MUSHGLOOM_MEEF_PASTA.item.get(),
							1, 200, 0.35f, Items.BOWL)::unlockedBy,
					DelightFood.MUSHGLOOM_SAUCE.item.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(DelightFood.MUSHGLOOM_SAUCE.item.get())
					.addIngredient(TagGen.MEEF_RAW)
					.addIngredient(ModItems.RAW_PASTA.get())
					.save(pvd, getID(DelightFood.MUSHGLOOM_MEEF_PASTA.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(TFItems.MEEF_STROGANOFF.get(),
							1, 200, 0.35f, Items.BOWL)::unlockedBy,
					DelightFood.RAW_TOMAHAWK_SMEAK.item.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(Items.MUSHROOM_STEW)
					.addIngredient(DelightFood.RAW_TOMAHAWK_SMEAK.item.get())
					.addIngredient(TFItems.LIVEROOT.get())
					.addIngredient(TFItems.TORCHBERRIES.get())
					.addIngredient(ModItems.ONION.get())
					.save(pvd, getID(TFItems.MEEF_STROGANOFF.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.GRILLED_GHAST.item.get(),
							1, 800, 0.35f, Items.BOWL)::unlockedBy,
					TFItems.EXPERIMENT_115.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(ModItems.TOMATO.get())
					.addIngredient(Items.BEETROOT)
					.addIngredient(ItemTagGenerator.FIERY_VIAL)
					.addIngredient(TFItems.EXPERIMENT_115.get(), 2)
					.save(pvd, getID(DelightFood.GRILLED_GHAST.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.GRILLED_TOMAHAWK_SMEAK.item.get(),
							1, 1600, 0.35f, Items.BOWL)::unlockedBy,
					DelightFood.RAW_TOMAHAWK_SMEAK.item.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(DelightFood.RAW_TOMAHAWK_SMEAK.item.get())
					.addIngredient(DelightFood.MUSHGLOOM_SAUCE.item.get())
					.addIngredient(TagRef.FOODS_MILK)
					.save(pvd, getID(DelightFood.GRILLED_TOMAHAWK_SMEAK.item.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(TDBlocks.LILY_CHICKEN.get().asItem(),
						1, 400, 0.35f)::unlockedBy,
				TFBlocks.HUGE_LILY_PAD.get().asItem())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(TFBlocks.HUGE_LILY_PAD.get().asItem())
				.addIngredient(ModBlocks.ROAST_CHICKEN_BLOCK.get().asItem())
				.addIngredient(TFBlocks.HUGE_WATER_LILY.get().asItem())
				.save(pvd, getID(TDBlocks.LILY_CHICKEN.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.NAGA_STEW.item.get(),
						1, 200, 0.35f, Items.BOWL)::unlockedBy,
				DelightFood.RAW_NAGA_PIECE.item.get())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(TagGen.NAGA_RAW)
				.addIngredient(TagGen.NAGA_RAW)
				.addIngredient(TagRef.FOODS_ONION)
				.addIngredient(TagRef.FOODS_LEAFY_GREEN)
				.save(pvd, getID(DelightFood.NAGA_STEW.item.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.NAGA_MEATBALL_CONGEE.item.get(),
						1, 200, 0.35f, Items.BOWL)::unlockedBy,
				DelightFood.RAW_NAGA_PIECE.item.get())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(TagGen.NAGA_RAW)
				.addIngredient(TagGen.NAGA_RAW)
				.addIngredient(Items.CARROT)
				.addIngredient(Items.DRIED_KELP)
				.addIngredient(TagRef.CROPS_RICE)
				.save(pvd, getID(DelightFood.NAGA_MEATBALL_CONGEE.item.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.WITCHCRAFT_BONE_BROTH.item.get(),
						1, 200, 0.35f, Items.BOWL)::unlockedBy,
				TDItems.WITCHCRAFT_BONE.get())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(TDItems.WITCHCRAFT_BONE.get())
				.addIngredient(Items.LAPIS_LAZULI)
				.addIngredient(Items.AMETHYST_SHARD)
				.addIngredient(Ingredient.of(Items.BROWN_MUSHROOM, Items.RED_MUSHROOM,
						TFBlocks.MUSHGLOOM.get().asItem()))
				.save(pvd, getID(DelightFood.WITCHCRAFT_BONE_BROTH.item.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(TDItems.CHAOS_INK_DRINK.get(),
						1, 200, 0.35f, TFItems.GREATER_FLASK.get())::unlockedBy,
				TDItems.WITCHCRAFT_BONE_MEAL.get())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(Items.INK_SAC, 2)
				.addIngredient(TDItems.WITCHCRAFT_BONE_MEAL.get())
				.addIngredient(TFItems.RAVEN_FEATHER.get())
				.addIngredient(Ingredient.of(TFItems.ZOMBIE_SCEPTER.get(),
						TFItems.TWILIGHT_SCEPTER.get(), TFItems.LIFEDRAIN_SCEPTER.get()))
				.save(pvd, getID(TDItems.CHAOS_INK_DRINK.getId()));

		unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(TDBlocks.CHAOS_STEW.get().asItem(),
						1, 400, 0.5f, TFBlocks.LICH_TROPHY.get().asItem())::unlockedBy,
				DelightFood.WITCHCRAFT_BONE_BROTH.item.get())
				.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
				.addIngredient(DelightFood.WITCHCRAFT_BONE_BROTH.item.get())
				.addIngredient(Items.ENDER_PEARL, 2)
				.addIngredient(Items.NETHER_WART, 2)
				.addIngredient(TFItems.RAVEN_FEATHER.get())
				.save(pvd, getID(TDBlocks.CHAOS_STEW.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.THOUSAND_PLANT_STEW.item.get(),
							1, 400, 0.35f, Items.BOWL)::unlockedBy,
					TFItems.LIVEROOT.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(TFBlocks.ROOT_STRAND.get().asItem())
					.addIngredient(TFBlocks.FALLEN_LEAVES.get().asItem())
					.addIngredient(TFItems.LIVEROOT.get())
					.addIngredient(TFBlocks.TORCHBERRY_PLANT.get().asItem())
					.addIngredient(Items.VINE)
					.addIngredient(TFBlocks.FIDDLEHEAD.get().asItem())
					.save(pvd, getID(DelightFood.THOUSAND_PLANT_STEW.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(TFItems.TRANSFORMATION_POWDER.get().asItem(),
							1, 800, 0.5f, ModItems.CANVAS.get())::unlockedBy,
					TFItems.BORER_ESSENCE.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MISC)
					.addIngredient(Items.NETHER_WART)
					.addIngredient(Items.FERMENTED_SPIDER_EYE)
					.addIngredient(Items.PUFFERFISH)
					.addIngredient(Items.POISONOUS_POTATO)
					.addIngredient(ModItems.ROTTEN_TOMATO.get())
					.addIngredient(TFItems.BORER_ESSENCE.get())
					.save(pvd, getID(TFItems.TRANSFORMATION_POWDER.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.LIVEROOT_PORK_FRIED_RICE.item,
							1, 200, 0.5f, Items.BOWL)::unlockedBy,
					TFItems.LIVEROOT.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(TagRef.CROPS_RICE)
					.addIngredient(TagRef.FOODS_RAW_PORK)
					.addIngredient(TagRef.FOODS_RAW_PORK)
					.addIngredient(Tags.Items.EGGS)
					.addIngredient(TFItems.LIVEROOT.get())
					.save(pvd, getID(DelightFood.LIVEROOT_PORK_FRIED_RICE.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.LIVEROOT_VENISON_NOODLE_SOUP.item,
							1, 200, 0.5f, Items.BOWL)::unlockedBy,
					TFItems.LIVEROOT.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.MEALS)
					.addIngredient(TagRef.FOODS_PASTA)
					.addIngredient(TagGen.VENSION_RAW)
					.addIngredient(ModItems.CHICKEN_SOUP.get())
					.addIngredient(TFItems.LIVEROOT.get())
					.save(pvd, getID(DelightFood.LIVEROOT_VENISON_NOODLE_SOUP.item.getId()));

		}

		// drink cooking
		{

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.TEAR_DRINK.item.get().asItem(),
							1, 800, 0.35f, Items.GLASS_BOTTLE)::unlockedBy,
					TFItems.FIERY_TEARS.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.DRINKS)
					.addIngredient(TFItems.FIERY_TEARS.get())
					.addIngredient(Items.GHAST_TEAR)
					.save(pvd, getID(DelightFood.TEAR_DRINK.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.PHYTOCHEMICAL_JUICE.item.get().asItem(),
							1, 200, 0.35f, Items.GLASS_BOTTLE)::unlockedBy,
					TFItems.LIVEROOT.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.DRINKS)
					.addIngredient(TFItems.LIVEROOT.get())
					.addIngredient(TFItems.STEELEAF_INGOT.get())
					.addIngredient(Items.SUGAR)
					.save(pvd, getID(DelightFood.PHYTOCHEMICAL_JUICE.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.THORN_ROSE_TEA.item.get().asItem(),
							1, 200, 0.35f, Items.GLASS_BOTTLE)::unlockedBy,
					TFBlocks.THORN_ROSE.get().asItem())
					.setRecipeBookTab(CookingPotRecipeBookTab.DRINKS)
					.addIngredient(TFBlocks.THORN_ROSE.get().asItem())
					.addIngredient(Items.SUGAR)
					.save(pvd, getID(DelightFood.THORN_ROSE_TEA.item.getId()));

			unlock(pvd, CookingPotRecipeBuilder.cookingPotRecipe(DelightFood.TORCHBERRY_JUICE.item.get().asItem(),
							1, 200, 0.35f, Items.GLASS_BOTTLE)::unlockedBy,
					TFItems.TORCHBERRIES.get())
					.setRecipeBookTab(CookingPotRecipeBookTab.DRINKS)
					.addIngredient(TFItems.TORCHBERRIES.get())
					.addIngredient(Items.SUGAR)
					.save(pvd, getID(DelightFood.TORCHBERRY_JUICE.item.getId()));
		}

		// cutting
		{
			path = "cutting/";

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TFItems.RAW_MEEF.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.RAW_MEEF_SLICE.item.get(), 2)
				.build(TGCompat.noTG(pvd, TGCompat.loc("minced_meef")), getID(DelightFood.RAW_MEEF_SLICE.item.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TFItems.COOKED_MEEF.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.COOKED_MEEF_SLICE.item.get(), 2)
				.build(TGCompat.noTG(pvd, TGCompat.loc("minced_meef")), getID(DelightFood.COOKED_MEEF_SLICE.item.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(DelightFood.RAW_TOMAHAWK_SMEAK.item.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.RAW_MEEF_SLICE.item.get(), 4)
				.build(TGCompat.noTG(pvd, TGCompat.loc("minced_meef")), getID(DelightFood.RAW_MEEF_SLICE.item.getId(), "_from_tomahawk"));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(DelightFood.COOKED_TOMAHAWK_SMEAK.item.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.COOKED_MEEF_SLICE.item.get(), 4)
				.build(TGCompat.noTG(pvd, TGCompat.loc("minced_meef")), getID(DelightFood.COOKED_MEEF_SLICE.item.getId(), "_from_tomahawk"));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TFItems.RAW_VENISON.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.RAW_VENISON_RIB.item.get(), 2)
				.build(TGCompat.noTG(pvd, TGCompat.loc("ground_venison")), getID(DelightFood.RAW_VENISON_RIB.item.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TFItems.COOKED_VENISON.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.COOKED_VENISON_RIB.item.get(), 2)
				.build(TGCompat.noTG(pvd, TGCompat.loc("ground_venison")), getID(DelightFood.COOKED_VENISON_RIB.item.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFItems.HYDRA_CHOP.get()),
							Ingredient.of(TagRef.KNIFE),
							DelightFood.HYDRA_PIECE.item.get(), 2)
					.build(pvd, getID(DelightFood.HYDRA_PIECE.item.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TagGen.INSECT),
							Ingredient.of(TagRef.KNIFE),
							DelightFood.RAW_INSECT.item.get(), 2)
					.build(pvd, getID(DelightFood.RAW_INSECT.item.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TDBlocks.MUSHGLOOM_COLONY.get()),
						Ingredient.of(TagRef.KNIFE),
						TFBlocks.MUSHGLOOM.get(), 5)
				.build(TGCompat.noTG(pvd, TGCompat.loc("mushgloom_colony")), getID(TDBlocks.MUSHGLOOM_COLONY.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TDBlocks.FIDDLEHEAD_CLUMP.get()),
						Ingredient.of(TagRef.KNIFE),
						TFBlocks.FIDDLEHEAD.get(), 5)
				.save(pvd, getID(TDBlocks.FIDDLEHEAD_CLUMP.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFBlocks.UR_GHAST_TROPHY.get()),
							Ingredient.of(TagRef.KNIFE),
							DelightFood.EXPERIMENT_113.item.get(), 9)
					.addResult(TFItems.EXPERIMENT_115.get(), 4)
					.addResultWithChance(DelightFood.EXPERIMENT_110.item.get(), 0.3f)
					.build(pvd, getID(TFBlocks.UR_GHAST_TROPHY.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFBlocks.HYDRA_TROPHY.get()),
							Ingredient.of(TagRef.KNIFE),
							TFItems.HYDRA_CHOP.get(), 4)
					.build(pvd, getID(TFBlocks.HYDRA_TROPHY.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TFBlocks.NAGA_TROPHY.get()),
						Ingredient.of(TagRef.KNIFE),
						TFItems.NAGA_SCALE.get(), 9)
				.addResult(DelightFood.RAW_NAGA_MEAT.item.get(), 6)
				.build(pvd, getID(TFBlocks.NAGA_TROPHY.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(DelightFood.RAW_NAGA_MEAT.item.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.RAW_NAGA_PIECE.item.get(), 2)
				.addResultWithChance(TFItems.NAGA_SCALE.get(), 0.5f)
				.build(pvd, getID(DelightFood.RAW_NAGA_PIECE.item.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(DelightFood.COOKED_NAGA_MEAT.item.get()),
						Ingredient.of(TagRef.KNIFE),
						DelightFood.COOKED_NAGA_PIECE.item.get(), 2)
				.build(pvd, getID(DelightFood.COOKED_NAGA_PIECE.item.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFBlocks.KNIGHT_PHANTOM_TROPHY.get()),
							Ingredient.of(TagRef.KNIFE),
							TFItems.PHANTOM_HELMET.get(), 1)
					.build(pvd, getID(TFBlocks.KNIGHT_PHANTOM_TROPHY.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(TFBlocks.LICH_TROPHY.get()),
						Ingredient.of(TagRef.KNIFE),
						Items.SKELETON_SKULL, 1)
				.addResult(TDItems.WITCHCRAFT_BONE.get(), 3)
				.addResultWithChance(TFItems.EXANIMATE_ESSENCE.get(), 0.5f)
				.build(pvd, getID(TFBlocks.LICH_TROPHY.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFBlocks.MINOSHROOM_TROPHY.get()),
							Ingredient.of(TagRef.KNIFE),
							TFItems.RAW_MEEF.get(), 9)
					.addResultWithChance(Items.RED_MUSHROOM, 0.5f, 8)
					.build(pvd, getID(TFBlocks.MINOSHROOM_TROPHY.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFBlocks.ALPHA_YETI_TROPHY.get()),
							Ingredient.of(TagRef.KNIFE),
							TFItems.ALPHA_YETI_FUR.get(), 9)
					.addResultWithChance(TFItems.ICE_BOMB.get(), 0.5f, 4)
					.build(pvd, getID(TFBlocks.ALPHA_YETI_TROPHY.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFItems.PHANTOM_HELMET.get()),
							Ingredient.of(ItemTags.PICKAXES),
							TFItems.ARMOR_SHARD_CLUSTER.get(), 3)
					.build(pvd, getID(TFItems.PHANTOM_HELMET.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFItems.PHANTOM_CHESTPLATE.get()),
							Ingredient.of(ItemTags.PICKAXES),
							TFItems.ARMOR_SHARD_CLUSTER.get(), 5)
					.build(pvd, getID(TFItems.PHANTOM_CHESTPLATE.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFBlocks.SNOW_QUEEN_TROPHY.get()),
							Ingredient.of(TagRef.KNIFE),
							TFItems.ICE_BOMB.get(), 9)
					.addResultWithChance(TFItems.ICE_SWORD.get(), 0.2f)
					.addResultWithChance(TFItems.GLASS_SWORD.get(), 0.1f)
					.addResultWithChance(TFItems.ICE_BOW.get(), 0.2f)
					.build(pvd, getID(TFBlocks.SNOW_QUEEN_TROPHY.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFBlocks.QUEST_RAM_TROPHY.get()),
							Ingredient.of(TagRef.KNIFE),
							Items.MUTTON, 9)
					.build(pvd, getID(TFBlocks.QUEST_RAM_TROPHY.getId()));

			CuttingBoardRecipeBuilder.cuttingRecipe(
							Ingredient.of(TFItems.NAGA_SCALE.get()),
							Ingredient.of(TFItems.DIAMOND_MINOTAUR_AXE.get()),
							DelightFood.NAGA_CHIP.item.get(), 4)
					.build(pvd, getID(TFItems.NAGA_SCALE.getId()));

		}

		// scepter duplication
		{
			unlock(pvd, new CustomShapedBuilder<>(ScepterDuplicateRecipe::new, TFItems.ZOMBIE_SCEPTER.get(), 1)::unlockedBy,
					TFItems.ZOMBIE_SCEPTER.get())
					.pattern("MMM").pattern("MSM").pattern("MBM")
					.define('M', Items.ROTTEN_FLESH)
					.define('S', TFItems.ZOMBIE_SCEPTER.get())
					.define('B', TDItems.WITCHCRAFT_BONE.get())
					.save(pvd, TwilightDelight.loc("scepter_duplicate_zombie"));

			unlock(pvd, new CustomShapedBuilder<>(ScepterDuplicateRecipe::new, TFItems.TWILIGHT_SCEPTER.get(), 1)::unlockedBy,
					TFItems.TWILIGHT_SCEPTER.get())
					.pattern("MMM").pattern("MSM").pattern("MBM")
					.define('M', Tags.Items.ENDER_PEARLS)
					.define('S', TFItems.TWILIGHT_SCEPTER.get())
					.define('B', TDItems.WITCHCRAFT_BONE.get())
					.save(pvd, TwilightDelight.loc("scepter_duplicate_twilight"));

			unlock(pvd, new CustomShapedBuilder<>(ScepterDuplicateRecipe::new, TFItems.LIFEDRAIN_SCEPTER.get(), 1)::unlockedBy,
					TFItems.LIFEDRAIN_SCEPTER.get())
					.pattern("MMM").pattern("MSM").pattern("MBM")
					.define('M', Items.FERMENTED_SPIDER_EYE)
					.define('S', TFItems.LIFEDRAIN_SCEPTER.get())
					.define('B', TDItems.WITCHCRAFT_BONE.get())
					.save(pvd, TwilightDelight.loc("scepter_duplicate_lifedrain"));

			unlock(pvd, new CustomShapedBuilder<>(ScepterDuplicateRecipe::new, TFItems.FORTIFICATION_SCEPTER.get(), 1)::unlockedBy,
					TFItems.FORTIFICATION_SCEPTER.get())
					.pattern(" M ").pattern("MSM").pattern(" B ")
					.define('M', Items.GOLDEN_APPLE)
					.define('S', TFItems.FORTIFICATION_SCEPTER.get())
					.define('B', TDItems.WITCHCRAFT_BONE.get())
					.save(pvd, TwilightDelight.loc("scepter_duplicate_fortification"));
		}

		// freezing
		{
			unlock(pvd, new SimpleFrozenRecipeBuilder(Ingredient.of(Items.BLUE_ICE), TFItems.ICE_BOMB.get())::unlockedBy,
					Items.BLUE_ICE).save(pvd, ResourceLocation.parse(getID(TFItems.ICE_BOMB.getId())));

			unlock(pvd, new SimpleFrozenRecipeBuilder(Ingredient.of(Items.MAGMA_BLOCK), Items.OBSIDIAN)::unlockedBy,
					Items.MAGMA_BLOCK).save(pvd, ResourceLocation.fromNamespaceAndPath(TwilightDelight.MODID, "obsidian"));

			unlock(pvd, new SimpleFrozenRecipeBuilder(Ingredient.of(Items.ICE), Items.PACKED_ICE)::unlockedBy,
					Items.ICE).save(pvd, ResourceLocation.fromNamespaceAndPath(TwilightDelight.MODID, "packed_ice"));

			unlock(pvd, new SimpleFrozenRecipeBuilder(Ingredient.of(Items.DIAMOND_SWORD), TFItems.ICE_SWORD.get())::unlockedBy,
					Items.DIAMOND_SWORD).save(pvd, ResourceLocation.parse(getID(TFItems.ICE_SWORD.getId())));

			unlock(pvd, new SimpleFrozenRecipeBuilder(Ingredient.of(Items.BOW), TFItems.ICE_BOW.get())::unlockedBy,
					Items.BOW).save(pvd, ResourceLocation.parse(getID(TFItems.ICE_BOW.getId())));

			unlock(pvd, new SimpleFrozenRecipeBuilder(Ingredient.of(ModItems.DIAMOND_KNIFE.get()), TDItems.ICE_KNIFE.get())::unlockedBy,
					ModItems.DIAMOND_KNIFE.get()).save(pvd, ResourceLocation.parse(getID(TDItems.ICE_KNIFE.getId())));
		}

		// log stripping
		{
			path = "stripping/";
			stripLog(pvd, TFBlocks.TWILIGHT_OAK_LOG, TFBlocks.STRIPPED_TWILIGHT_OAK_LOG);
			stripLog(pvd, TFBlocks.CANOPY_LOG, TFBlocks.STRIPPED_CANOPY_LOG);
			stripLog(pvd, TFBlocks.DARK_LOG, TFBlocks.STRIPPED_DARK_LOG);
			stripLog(pvd, TFBlocks.MANGROVE_LOG, TFBlocks.STRIPPED_MANGROVE_LOG);
			stripLog(pvd, TFBlocks.MINING_LOG, TFBlocks.STRIPPED_MINING_LOG);
			stripLog(pvd, TFBlocks.TIME_LOG, TFBlocks.STRIPPED_TIME_LOG);
			stripLog(pvd, TFBlocks.SORTING_LOG, TFBlocks.STRIPPED_SORTING_LOG);
			stripLog(pvd, TFBlocks.TRANSFORMATION_LOG, TFBlocks.STRIPPED_TRANSFORMATION_LOG);

			stripLog(pvd, TFBlocks.TWILIGHT_OAK_WOOD, TFBlocks.STRIPPED_TWILIGHT_OAK_WOOD);
			stripLog(pvd, TFBlocks.CANOPY_WOOD, TFBlocks.STRIPPED_CANOPY_WOOD);
			stripLog(pvd, TFBlocks.DARK_WOOD, TFBlocks.STRIPPED_DARK_WOOD);
			stripLog(pvd, TFBlocks.MANGROVE_WOOD, TFBlocks.STRIPPED_MANGROVE_WOOD);
			stripLog(pvd, TFBlocks.MINING_WOOD, TFBlocks.STRIPPED_MINING_WOOD);
			stripLog(pvd, TFBlocks.TIME_WOOD, TFBlocks.STRIPPED_TIME_WOOD);
			stripLog(pvd, TFBlocks.SORTING_WOOD, TFBlocks.STRIPPED_SORTING_WOOD);
			stripLog(pvd, TFBlocks.TRANSFORMATION_WOOD, TFBlocks.STRIPPED_TRANSFORMATION_WOOD);
		}

		if (ModList.get().isLoaded(Neapolitan.MOD_ID)) {
			path = "neapolitan/";
			neapolitan(pvd, NeapolitanFood.AURORA_ICE_CREAM.item,
					NeapolitanFood.AURORA_MILKSHAKE.item,
					NeapolitanCakes.AURORA,
					TFBlocks.AURORA_BLOCK.get().asItem());
			neapolitan(pvd, NeapolitanFood.GLACIER_ICE_CREAM.item,
					NeapolitanFood.GLACIER_MILKSHAKE.item,
					NeapolitanCakes.GLACIER,
					TFItems.ICE_BOMB.get());
			neapolitan(pvd, NeapolitanFood.PHYTOCHEMICAL_ICE_CREAM.item,
					NeapolitanFood.PHYTOCHEMICAL_MILKSHAKE.item,
					NeapolitanCakes.PHYTOCHEMICAL,
					TFItems.STEELEAF_INGOT.get());
			neapolitan(pvd, NeapolitanFood.TORCHBERRY_ICE_CREAM.item,
					NeapolitanFood.TORCHBERRY_MILKSHAKE.item,
					NeapolitanCakes.TORCHBERRY,
					TFItems.TORCHBERRIES.get());

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, NeapolitanFood.TWILIGHT_ICE_CREAM.item.get(), 3)::unlockedBy, TFItems.TORCHBERRIES.get())
					.requires(NeapolitanFood.TORCHBERRY_ICE_CREAM.item.get())
					.requires(NeapolitanItems.CHOCOLATE_ICE_CREAM.get())
					.requires(NeapolitanItems.STRAWBERRY_ICE_CREAM.get())
					.requires(Items.BOWL, 3).save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID));

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, NeapolitanFood.RAINBOW_ICE_CREAM.item.get(), 3)::unlockedBy, TFBlocks.AURORA_BLOCK.get().asItem())
					.requires(NeapolitanFood.AURORA_ICE_CREAM.item.get())
					.requires(NeapolitanItems.BANANA_ICE_CREAM.get())
					.requires(NeapolitanItems.ADZUKI_ICE_CREAM.get())
					.requires(Items.BOWL, 3).save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID));

			unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, NeapolitanFood.REFRESHING_ICE_CREAM.item.get(), 3)::unlockedBy, TFItems.ICE_BOMB.get())
					.requires(NeapolitanFood.GLACIER_ICE_CREAM.item.get())
					.requires(NeapolitanItems.MINT_ICE_CREAM.get())
					.requires(NeapolitanFood.PHYTOCHEMICAL_ICE_CREAM.item.get())
					.requires(Items.BOWL, 3).save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID));

		}

	}

	private static void delightPie(RegistrateRecipeProvider pvd, DelightPie pie, Item ingredient) {
		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, pie.block.asItem(), 1)::unlockedBy, ingredient)
				.pattern("###").pattern("aaa").pattern("xOx")
				.define('#', Items.WHEAT)
				.define('a', ingredient)
				.define('x', Items.SUGAR)
				.define('O', ModItems.PIE_CRUST.get())
				.save(pvd);

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, pie.block.asItem(), 1)::unlockedBy, pie.slice.get())
				.pattern("##").pattern("##")
				.define('#', pie.slice.get())
				.save(pvd, getID(pie.block.getId(), "_from_slices"));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(pie.block.get()),
						Ingredient.of(TagRef.KNIFE),
						pie.slice.get(), 4)
				.build(pvd, getID(pie.slice.getId()));
	}

	private static void delightCake(RegistrateRecipeProvider pvd, DelightCake cake) {
		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, cake.block.get().asItem(), 1)::unlockedBy, Items.DIAMOND)
				.pattern(" DP").pattern("GWG").pattern("TCT")
				.define('D', Items.DIAMOND).define('P', Items.POPPY)
				.define('G', Items.GRASS_BLOCK).define('W', Items.WATER_BUCKET)
				.define('T', Items.DIRT).define('C', Items.CAKE)
				.save(pvd);

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(cake.block.get()),
						Ingredient.of(TagRef.KNIFE),
						cake.slice.get(), 7)
				.build(pvd, getID(cake.slice.getId()));

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, cake.block.get(), 1)::unlockedBy, cake.slice.get())
				.requires(cake.slice.get(), 7)
				.save(pvd, getID(cake.block.getId()) + "_assemble");
	}

	private static void neapolitan(RegistrateRecipeProvider pvd, ItemEntry<?> ice_cream, ItemEntry<?> milkshake, NeapolitanCakes cake, Item ingredient) {
		var milk = TagRef.FOODS_MILK;
		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, ice_cream.get(), 1)::unlockedBy, ingredient)
				.requires(Items.BOWL).requires(milk).requires(NeapolitanItems.ICE_CUBES.get()).requires(Items.SUGAR)
				.requires(ingredient)
				.save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID), getID(ice_cream.getId()));

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, milkshake.get(), 3)::unlockedBy, ingredient)
				.requires(Items.GLASS_BOTTLE, 3).requires(milk).requires(NeapolitanItems.VANILLA_ICE_CREAM.get())
				.requires(ingredient)
				.save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID), getID(milkshake.getId()));

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, milkshake.get(), 3)::unlockedBy, ingredient)
				.requires(Items.GLASS_BOTTLE, 3).requires(milk).requires(ice_cream.get())
				.requires(NeapolitanItems.DRIED_VANILLA_PODS.get())
				.save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID), getID(milkshake.getId()) + "_alt");

		unlock(pvd, new ShapedRecipeBuilder(RecipeCategory.FOOD, cake.block.get().asItem(), 1)::unlockedBy, ingredient)
				.pattern("MXM").pattern("SES").pattern("WXW")
				.define('M', milk).define('S', Items.SUGAR)
				.define('W', Items.WHEAT).define('E', Tags.Items.EGGS)
				.define('X', ingredient)
				.save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID), getID(cake.block.getId()));

		CuttingBoardRecipeBuilder.cuttingRecipe(
						Ingredient.of(cake.block.get()),
						Ingredient.of(TagRef.KNIFE),
						cake.item.get(), 7)
				.build(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID), getID(cake.item.getId()));

		unlock(pvd, new ShapelessRecipeBuilder(RecipeCategory.FOOD, cake.block.get(), 1)::unlockedBy, cake.item.get())
				.requires(cake.item.get(), 7)
				.save(ConditionalRecipeWrapper.mod(pvd, Neapolitan.MOD_ID), getID(cake.block.getId()) + "_assemble");
	}

	private static String getID(ResourceLocation item) {
		return TwilightDelight.MODID + ":" + path + item.getPath();
	}

	private static String getID(ResourceLocation item, String suffix) {
		return TwilightDelight.MODID + ":" + path + item.getPath() + suffix;
	}

	private static <T> T unlock(RegistrateRecipeProvider pvd, BiFunction<String, Criterion<InventoryChangeTrigger.TriggerInstance>, T> func, Item item) {
		return func.apply("has_" + pvd.safeName(item), DataIngredient.items(item).getCriterion(pvd));
	}

	private static void tripleCook(RegistrateRecipeProvider pvd, DataIngredient in, Supplier<Item> out, int exp) {
		pvd.smelting(in, RecipeCategory.FOOD, out, exp, 200);
		pvd.smoking(in, RecipeCategory.FOOD, out, exp, 100);
		pvd.campfire(in, RecipeCategory.FOOD, out, exp, 300);
	}

	// same output shape as RegistrateRecipeProvider helpers, but saved through the given output
	// so neoforge conditions can be attached
	private static void tripleCookCond(RecipeOutput out, Item ingredient, Supplier<Item> result, int exp) {
		var rloc = BuiltInRegistries.ITEM.getKey(result.get());
		var iloc = BuiltInRegistries.ITEM.getKey(ingredient);
		String base = rloc.getPath() + "_from_" + iloc.getPath();
		String crit = "has_" + iloc.getPath();
		var trigger = InventoryChangeTrigger.TriggerInstance.hasItems(ingredient);
		SimpleCookingRecipeBuilder.smelting(Ingredient.of(ingredient), RecipeCategory.FOOD, result.get(), exp, 200)
				.unlockedBy(crit, trigger).save(out, TwilightDelight.loc(base + "_smelting"));
		SimpleCookingRecipeBuilder.smoking(Ingredient.of(ingredient), RecipeCategory.FOOD, result.get(), exp, 100)
				.unlockedBy(crit, trigger).save(out, TwilightDelight.loc(base + "_smoking"));
		SimpleCookingRecipeBuilder.campfireCooking(Ingredient.of(ingredient), RecipeCategory.FOOD, result.get(), exp, 300)
				.unlockedBy(crit, trigger).save(out, TwilightDelight.loc(base + "_campfire"));
	}

	private static void stripLog(RegistrateRecipeProvider pvd, DeferredBlock<? extends Block> log, DeferredBlock<? extends Block> stripped) {
		CuttingBoardRecipeBuilder.cuttingRecipe(Ingredient.of(log.get()), new ItemAbilityIngredient(ItemAbilities.AXE_STRIP).toVanilla(), stripped.get())
				.addResult(ModItems.TREE_BARK.get())
				.addSound(SoundEvents.AXE_STRIP)
				.build(pvd, getID(stripped.getId()));
	}

}
