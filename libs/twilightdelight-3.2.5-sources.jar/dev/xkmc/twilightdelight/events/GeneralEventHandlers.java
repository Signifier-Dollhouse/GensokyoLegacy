package dev.xkmc.twilightdelight.events;

import dev.xkmc.twilightdelight.init.TwilightDelight;
import dev.xkmc.twilightdelight.init.data.ExtraLootGen;
import dev.xkmc.twilightdelight.init.data.TagRef;
import dev.xkmc.twilightdelight.init.registrate.TDBlocks;
import dev.xkmc.twilightdelight.init.registrate.TDEffects;
import dev.xkmc.twilightdelight.init.registrate.TDItems;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.network.protocol.game.ClientboundAnimatePacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import twilightforest.block.Experiment115Block;
import twilightforest.init.TFBlocks;
import twilightforest.init.TFMobEffects;

@EventBusSubscriber(modid = TwilightDelight.MODID, bus = EventBusSubscriber.Bus.GAME)
public class GeneralEventHandlers {

	private static ObjectArrayList<ItemStack> getLoot(ServerLevel sl, ResourceKey<LootTable> id, BlockState state, PlayerInteractEvent.RightClickBlock event) {
		var ctx = new LootParams.Builder(sl)
				.withParameter(LootContextParams.BLOCK_STATE, state)
				.withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(event.getPos()))
				.withParameter(LootContextParams.TOOL, event.getItemStack())
				.withParameter(LootContextParams.THIS_ENTITY, event.getEntity())
				.create(LootContextParamSets.BLOCK);
		return sl.getServer().reloadableRegistries().getLootTable(id)
				.getRandomItems(ctx);
	}

	@SubscribeEvent
	public static void onItemUse(PlayerInteractEvent.RightClickBlock event) {
		BlockState state = event.getLevel().getBlockState(event.getPos());
		// bone meal on uberous soil turns it into twilight rich soil
		if (event.getItemStack().is(TDItems.WITCHCRAFT_BONE_MEAL.get()) && state.is(TFBlocks.UBEROUS_SOIL.get())) {
			Level level = event.getLevel();
			if (level instanceof ServerLevel sl) {
				sl.setBlockAndUpdate(event.getPos(), TDBlocks.TWILIGHT_RICH_SOIL.get().defaultBlockState());
				sl.playSound(null, event.getPos(), SoundEvents.BONE_MEAL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
				if (!event.getEntity().getAbilities().instabuild) {
					event.getItemStack().shrink(1);
				}
			}
			event.setCanceled(true);
			event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide()));
		} else {
			if (state.is(TFBlocks.EXPERIMENT_115.get())) {
				if (event.getItemStack().is(Items.REDSTONE)) {
					if (!state.getValue(Experiment115Block.REGENERATE)) {
						if (state.getValue(Experiment115Block.BITES_TAKEN) > 0) {
							event.setCanceled(true);
							event.setCancellationResult(InteractionResult.FAIL);
						}
					}
				}
			}
			if (event.getItemStack().is(TagRef.KNIFE)) {
				if (state.is(TFBlocks.EXPERIMENT_115.get())) {
					if (event.getLevel() instanceof ServerLevel sl) {
						int i = state.getValue(Experiment115Block.BITES_TAKEN);
						if (i < 7) {
							event.getLevel().setBlock(event.getPos(), state.setValue(Experiment115Block.BITES_TAKEN, i + 1), 3);
						} else {
							event.getLevel().removeBlock(event.getPos(), false);
						}
						var loot = getLoot(sl, ExtraLootGen.SCRAP_115, state, event);
						for (var e : loot) {
							event.getEntity().getInventory().placeItemBackInInventory(e);
						}
						event.getItemStack().hurtAndBreak(1, event.getEntity(),
								LivingEntity.getSlotForHand(event.getHand()));
					}
					event.getLevel().playSound(event.getEntity(), event.getPos(),
							SoundEvents.WOOL_BREAK, SoundSource.BLOCKS, 1.0F, 1.0F);
					event.setCanceled(true);
					event.setCancellationResult(InteractionResult.SUCCESS);
				}
			}
		}
	}

	@SubscribeEvent
	public static void onPotionTest(MobEffectEvent.Applicable event) {
		if (event.getEffectInstance() == null) return;
		if (event.getEffectInstance().getEffect() == MobEffects.POISON && event.getEntity().hasEffect(TDEffects.POISON_RANGE)) {
			event.setResult(MobEffectEvent.Applicable.Result.DO_NOT_APPLY);
		}
		if (event.getEffectInstance().getEffect() == TFMobEffects.FROSTY.get() && event.getEntity().hasEffect(TDEffects.FROZEN_RANGE)) {
			event.setResult(MobEffectEvent.Applicable.Result.DO_NOT_APPLY);
		}
	}

	@SubscribeEvent
	public static void onKnightmetalToolDamage(LivingIncomingDamageEvent event) {
		if (event.getSource().getDirectEntity() instanceof LivingEntity living) {
			var item = living.getMainHandItem();
			if ((item.is(TDItems.FIERY_KNIFE.get()) || item.is(TDItems.TEARDROP_SWORD.get())) && !event.getEntity().fireImmune()) {
				event.getEntity().setRemainingFireTicks(20);
			}
			if (item.is(TDItems.ICE_KNIFE.get())) {
				event.getEntity().clearFire();
			}
		}

		LivingEntity target = event.getEntity();
		if (!target.level().isClientSide()) {
			Entity var3 = event.getSource().getDirectEntity();
			if (var3 instanceof LivingEntity living) {
				ItemStack weapon = living.getMainHandItem();
				if (!weapon.isEmpty()) {
					if (target.getArmorValue() > 0 && (weapon.is(TDItems.KNIGHTMETAL_KNIFE.get()))) {
						if (target.getArmorCoverPercentage() > 0.0F) {
							int moreBonus = (int) (2.0F * target.getArmorCoverPercentage());
							event.setAmount(event.getAmount() + (float) moreBonus);
						} else {
							event.setAmount(event.getAmount() + 2.0F);
						}
						((ServerLevel) target.level()).getChunkSource().broadcastAndSend(target, new ClientboundAnimatePacket(target, 5));
					}
				}
			}
		}

	}

}
