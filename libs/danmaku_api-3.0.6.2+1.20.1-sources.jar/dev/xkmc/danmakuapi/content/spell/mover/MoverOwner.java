package dev.xkmc.danmakuapi.content.spell.mover;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.TraceableEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Anything that can own a {@link MoverInfo}. Danmaku entities implement this through
 * {@code IDanmakuEntity}; non-danmaku shooters can implement it directly.
 */
public interface MoverOwner {

	Entity self();

	Vec3 rot();

	TraceableEntity asTraceable();

}
