package dev.xkmc.danmakuapi.api;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.eventbus.api.Cancelable;
import net.minecraftforge.eventbus.api.Event;
import org.jetbrains.annotations.Nullable;

/**
 * Posted by spell items after their raycast and before they decide whether a target is required.
 * <p>
 * Listeners may replace the target (for example with a graze-session target) or cancel the use.
 * Cancelling is equivalent to failing the item use.
 */
@Cancelable
public class DanmakuTargetEvent extends Event {

	private final Player player;
	private final boolean requireTarget;
	@Nullable
	private LivingEntity target;

	public DanmakuTargetEvent(Player player, @Nullable LivingEntity target, boolean requireTarget) {
		this.player = player;
		this.target = target;
		this.requireTarget = requireTarget;
	}

	public Player getPlayer() {
		return player;
	}

	@Nullable
	public LivingEntity getTarget() {
		return target;
	}

	public void setTarget(@Nullable LivingEntity target) {
		this.target = target;
	}

	public boolean isRequireTarget() {
		return requireTarget;
	}

}
