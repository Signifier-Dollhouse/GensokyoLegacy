package dev.xkmc.danmakuapi.api;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.Cancelable;
import net.minecraftforge.eventbus.api.Event;

@Cancelable
public class DanmakuUseEvent extends Event {

	private final Player player;
	private final ItemStack stack;
	private final InteractionHand hand;
	private int cooldown;
	private boolean consume;

	public DanmakuUseEvent(Player player, ItemStack stack, int cooldown) {
		this(player, stack, cooldown, InteractionHand.MAIN_HAND);
	}

	public DanmakuUseEvent(Player player, ItemStack stack, int cooldown, InteractionHand hand) {
		this.player = player;
		this.stack = stack;
		this.hand = hand;
		this.cooldown = cooldown;
		consume = !player.getAbilities().instabuild;
	}

	public ItemStack getStack() {
		return stack;
	}

	public Player getPlayer() {
		return player;
	}

	public InteractionHand getHand() {
		return hand;
	}

	public int getCooldown() {
		return cooldown;
	}

	public void setCooldown(int cooldown) {
		this.cooldown = cooldown;
	}

	public boolean consume() {
		return consume;
	}

	public void setConsume(boolean consume) {
		this.consume = consume;
	}

}
