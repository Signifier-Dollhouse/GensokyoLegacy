package dev.xkmc.danmakuapi.api;

import dev.xkmc.fastprojectileapi.entity.GrazingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Host-provided graze policy.
 * <p>
 * The library only defines when graze is attempted; what a graze means (resource, power,
 * packets, invulnerability, ...) is game content. Implementations are installed with
 * {@link GrazeHelper#setHandler(GrazeHandler)}.
 * <p>
 * {@link #hitBoxShrink(Player)} and {@link #forbidDanmaku(Player)} are queried from collision
 * and use paths, so they must be cheap. Do not post events from them.
 */
public interface GrazeHandler {

	/**
	 * Called after {@link DanmakuGrazeEvent} has been posted and not cancelled, and after
	 * {@link #isInvulnerable(Player)} returned false.
	 */
	void onGraze(Player player, GrazingEntity danmaku);

	/**
	 * Positive amount by which the player's hitbox is shrunk for danmaku collision.
	 * Return 0 for no shrink.
	 */
	float hitBoxShrink(Player player);

	/**
	 * Whether the player is currently forbidden from firing danmaku.
	 */
	boolean forbidDanmaku(Player player);

	/**
	 * Whether graze should be ignored entirely (for example during post-hit invulnerability).
	 * Checked before {@link DanmakuGrazeEvent} is posted.
	 */
	default boolean isInvulnerable(Player player) {
		return false;
	}

}
