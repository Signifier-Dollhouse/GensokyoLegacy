package dev.xkmc.danmakuapi.api;

import dev.xkmc.fastprojectileapi.entity.GrazingEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;

public class GrazeHelper {

	public static int globalInvulTime = 0;
	public static int globalForbidTime = 0;

	private static final GrazeHandler NOOP = new GrazeHandler() {
		@Override
		public void onGraze(Player player, GrazingEntity danmaku) {
		}

		@Override
		public float hitBoxShrink(Player player) {
			return 0;
		}

		@Override
		public boolean forbidDanmaku(Player player) {
			return false;
		}
	};

	private static GrazeHandler handler = NOOP;

	/**
	 * Installs the host's graze policy. Pass {@code null} to restore the no-op default.
	 */
	public static void setHandler(GrazeHandler handler) {
		GrazeHelper.handler = handler == null ? NOOP : handler;
	}

	public static GrazeHandler getHandler() {
		return handler;
	}

	public static void graze(Player entity, GrazingEntity e) {
		if (handler.isInvulnerable(entity)) return;
		if (MinecraftForge.EVENT_BUS.post(new DanmakuGrazeEvent(entity, e))) return;
		handler.onGraze(entity, e);
	}

	public static float getHitBoxShrink(Player player) {
		return handler.hitBoxShrink(player);
	}

	public static boolean shouldPlayerHurt(Player player, LivingEntity le) {
		boolean ans = shouldPlayerHurtImpl(player, le);
		var event = new DanmakuHurtEvent(player, le, ans);
		MinecraftForge.EVENT_BUS.post(event);
		return event.getAnswer();
	}

	private static boolean shouldPlayerHurtImpl(Player player, LivingEntity le) {
		if (le.isAlliedTo(player)) return false;
		if (le instanceof Animal animal && animal.getTarget() == null)
			return false;
		if (le instanceof AbstractVillager villager && villager.getTarget() == null)
			return false;
		if (le instanceof OwnableEntity ownable) {
			var owner = ownable.getOwner();
			if (owner != null && owner.isAlliedTo(player)) return false;
		}
		return true;
	}

	public static boolean forbidDanmaku(Player player) {
		return handler.forbidDanmaku(player);
	}

}
