package dev.xkmc.danmakuapi.api;

import dev.xkmc.fastprojectileapi.entity.GrazingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.Cancelable;

/**
 * Posted before a graze is handed to the installed {@link GrazeHandler}.
 * Cancel to suppress the graze for this tick.
 */
@Cancelable
public class DanmakuGrazeEvent extends PlayerEvent {

	private final GrazingEntity danmaku;

	public DanmakuGrazeEvent(Player player, GrazingEntity danmaku) {
		super(player);
		this.danmaku = danmaku;
	}

	public GrazingEntity getDanmaku() {
		return danmaku;
	}

}
